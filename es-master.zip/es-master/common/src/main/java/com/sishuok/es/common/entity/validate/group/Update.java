/**
 * Copyright (c) 2005-2012 https://github.com/zhangkaitao
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.sishuok.es.common.entity.validate.group;

/**
 * java bean validation 分组验证使用（表示修改分组）
 * <p>User: Zhang Kaitao
 * <p>Date: 13-2-8 下午4:38
 * <p>Version: 1.0
 */
public interface Update {
}
