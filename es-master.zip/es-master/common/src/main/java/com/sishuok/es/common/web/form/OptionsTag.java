/**
 * Copyright (c) 2005-2012 https://github.com/zhangkaitao
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.sishuok.es.common.web.form;

/**
 * 取值时
 * 1、先取parameter
 * 2、如果找不到再找attribute (page--->request--->session--->application)
 * <p>User: Zhang Kaitao
 * <p>Date: 13-3-28 下午3:11
 * <p>Version: 1.0
 */
public class OptionsTag extends org.springframework.web.servlet.tags.form.OptionsTag {

}
