package com.sishuok.es.maintain.dynamictask.exception;

/**
 * <p>User: Zhang Kaitao
 * <p>Date: 14-1-17
 * <p>Version: 1.0
 */
public class DynamicTaskException extends RuntimeException {
    public DynamicTaskException(String message, Throwable cause) {
        super(message, cause);
    }
}
